import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SudokuGUI extends JFrame {

    JTextField[][] cells = new JTextField[9][9];

    public SudokuGUI() {

        setTitle("Sudoku Solver");
        setSize(500, 500);
        setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(9, 9));

        // Create grid
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                cells[i][j] = new JTextField();
                cells[i][j].setHorizontalAlignment(JTextField.CENTER);
                cells[i][j].setFont(new Font("Arial", Font.BOLD, 18));
                gridPanel.add(cells[i][j]);
            }
        }

        JButton solveButton = new JButton("Solve");

        solveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                int[][] board = new int[9][9];

                // Read input
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        String text = cells[i][j].getText();
                        board[i][j] = text.isEmpty() ? 0 : Integer.parseInt(text);
                    }
                }

                // Run solver in new thread (important for animation)
                new Thread(() -> {
                    if (!solveSudoku(board)) {
                        JOptionPane.showMessageDialog(null, "No solution exists!");
                    }
                }).start();
            }
        });

        add(gridPanel, BorderLayout.CENTER);
        add(solveButton, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // 🧠 Backtracking with animation
    public boolean solveSudoku(int[][] board) {

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {

                if (board[row][col] == 0) {

                    for (int num = 1; num <= 9; num++) {

                        if (isSafe(board, row, col, num)) {

                            board[row][col] = num;

                            // Update GUI
                            cells[row][col].setText(String.valueOf(num));
                            cells[row][col].setForeground(Color.BLUE);

                            sleep(50);

                            if (solveSudoku(board))
                                return true;

                            // Backtrack
                            board[row][col] = 0;
                            cells[row][col].setText("");
                            cells[row][col].setForeground(Color.RED);

                            sleep(50);
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    // Check valid placement
    public boolean isSafe(int[][] board, int row, int col, int num) {

        for (int i = 0; i < 9; i++) {
            if (board[row][i] == num || board[i][col] == num)
                return false;
        }

        int startRow = row - row % 3;
        int startCol = col - col % 3;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[startRow + i][startCol + j] == num)
                    return false;
            }
        }

        return true;
    }

    // Delay function
    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new SudokuGUI();
    }
}
